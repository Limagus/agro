SITE AGRO & GEO SOLUÇÕES

Arquivos principais:
- index.html
- css/style.css
- js/script.js
- assets/logo.jpeg

COMO TESTAR NO COMPUTADOR
1. Extraia o arquivo ZIP.
2. Abra o arquivo index.html no navegador.

COMO PUBLICAR NO GITHUB PAGES
1. Crie um repositório no GitHub, por exemplo: agro-geo-site.
2. Envie todos os arquivos desta pasta para o repositório.
3. Vá em Settings > Pages.
4. Em Branch, escolha main e pasta /root.
5. Salve e aguarde o GitHub gerar o link.

COMO PUBLICAR NO INFINITYFREE
1. Acesse o painel do InfinityFree.
2. Abra o File Manager.
3. Entre na pasta htdocs.
4. Envie o index.html, a pasta css, a pasta js e a pasta assets.
5. Acesse o domínio configurado.

DADOS CONFIGURADOS
Nome: Agro & Geo Soluções
E-mail: agrogeo26@gmail.com
WhatsApp principal: (82) 99953-6495
WhatsApp secundário: (82) 98171-3939
Instagram: @agrogeosolucoes
Endereço: Rua Capela, nº 15, Vila Sergipe, Piranhas-AL
CNPJ: 66.731.006/0001-47
